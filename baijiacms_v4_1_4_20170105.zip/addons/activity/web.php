<?php
// +----------------------------------------------------------------------
// | 
// +----------------------------------------------------------------------
// | Copyright (c) 2015 http://www.baijiacms.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: �ټ����� <QQ:1987884799> <http://www.baijiacms.com>
// +----------------------------------------------------------------------
defined('SYSTEM_IN') or exit('Access Denied');
class activityAddons  extends BjModule {
		public function do_activity()
	{

			$this->__web(__FUNCTION__);
	}
			public function do_records()
	{

			$this->__web(__FUNCTION__);
	}
}